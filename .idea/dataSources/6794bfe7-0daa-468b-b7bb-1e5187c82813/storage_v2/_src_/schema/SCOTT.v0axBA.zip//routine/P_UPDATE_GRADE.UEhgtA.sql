create procedure p_update_grade is
 --根据工资级别查询员工scott相应的工资级别
  num number;
  cursor my_cursor is
    select * from emp;
  v_emp emp%rowtype;
begin
   open my_cursor;
  loop
    exit when my_cursor%notfound;
  
    fetch my_cursor
      into v_emp;
   if v_emp.sal>700 and v_emp.sal<=3200 then
     num:=1;
   elsif  v_emp.sal>3201 and v_emp.sal<=4400 then
     num:=2;
   elsif  v_emp.sal>4401 and v_emp.sal<=5000 then
     num:=3;
   elsif  v_emp.sal>5001 and v_emp.sal<=7000 then
     num:=4;
   else
     num:=5;
   end if;
  
   dbms_output.put_line('员工'||v_emp.ename||'的级别是' || num);
   end loop;
  commit;
end p_update_grade;
/

