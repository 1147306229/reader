create procedure p_update_comms is
v_comm number(7, 2);
  v_num  number;
  cursor my_cursor is
    select * from emp;
  v_emp emp%rowtype;
begin
   open my_cursor;
  loop
    exit when my_cursor%notfound;
  
    fetch my_cursor
      into v_emp;

  v_num := (sysdate - v_emp.hiredate) / 365;

  if v_num >= 6 then
    v_comm := 2000;
  
  elsif v_num < 6 then
    v_comm := 1500;
  end if;

  update emp e set e.comm = v_comm where e.empno =v_emp.empno;
  
  dbms_output.put_line('修改成功，'||v_emp.ename||'的奖金为' || v_comm);
  end loop;
  commit;
end p_update_comms;
/

