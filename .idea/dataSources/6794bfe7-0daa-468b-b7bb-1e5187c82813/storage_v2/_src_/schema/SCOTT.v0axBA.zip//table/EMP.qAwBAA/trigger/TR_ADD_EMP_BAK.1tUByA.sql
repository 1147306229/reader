create trigger TR_ADD_EMP_BAK
    after insert
    on EMP
    for each row
declare
  -- local variables here
begin
  --添加员工备份表，添加的值从原表的新增数据中获取
  --原表中新增的数据，通过关键字:new获取
  insert into emp_bak values(:new.empno,:new.ename,sysdate);
  
end tr_add_emp_bak;
/

