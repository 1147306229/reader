create procedure p_get_empsalary(cur_salary out sys_refcursor) is
begin
  --查询所有员工信息，结果集绑定到游标输出参数中
  open cur_salary for
    select * from emp;
end p_get_empsalary;
/

