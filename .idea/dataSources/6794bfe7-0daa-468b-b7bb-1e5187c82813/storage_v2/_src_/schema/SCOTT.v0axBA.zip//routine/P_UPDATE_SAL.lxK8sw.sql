create procedure p_update_sal is
v_result number(7,2);
  v_rate number(5,2);--税率
  v_kouchu number;--速算扣除数
  cursor my_cursor is
  select * from emp;
  v_emp emp%rowtype;
begin
  open my_cursor;
  loop
    exit when my_cursor%notfound;
    
    fetch my_cursor into v_emp;


   if v_emp.sal>=3500 then
     --工资-纳税起征点3500
     v_result := v_emp.sal - 3500.00;
  else
    v_result :=v_emp.sal;
  end if ;
  
  --判断工资要纳税的税率是哪一档
  if v_result<=1500 then
    v_rate:=0.03;
    v_kouchu:=0;
  elsif v_result>1500 and v_result <=4500 then
    v_rate :=0.1;
    v_kouchu:=105; 
  elsif v_result>4500 and v_result <=9500 then
    v_rate :=0.2;
    v_kouchu:=555;
   end if ;
   
   --纳税额=（工资-3500）*纳税-速算扣除数
   v_result :=v_result* v_rate-v_kouchu;
   
   dbms_output.put_line(v_emp.empno||'所交的纳税额是'||v_result);
    end loop;
end p_update_sal;
/

