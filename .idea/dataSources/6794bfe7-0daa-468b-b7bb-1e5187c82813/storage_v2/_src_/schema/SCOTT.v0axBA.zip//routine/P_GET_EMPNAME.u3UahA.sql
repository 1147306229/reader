create procedure p_get_empname(v_no in number,v_name out varchar2) is
begin
  select e.ename into v_name from emp e where e.empno=v_no;
  
  exception 
    when no_data_found then 
      v_name:='没有编号为'||v_no||'员工';
    when others then
      v_name:='系统未知异常';
  
end p_get_empname;
/

