create procedure p_update_comm is
 cursor my_cursor is
  select hiredate,empno from emp;
  v_hiredate emp.hiredate%type;
  v_total number;
  v_comm emp.comm%type;
  v_empno emp.empno%type;
begin
  open my_cursor;
  
  loop
    exit when my_cursor%notfound;
    
    fetch my_cursor into v_hiredate,v_empno;
    
    
    v_total:=(sysdate-v_hiredate)/365;
    
    if v_total>=6 then
      v_comm:=2000;
    else 
      v_comm:=1500;    
    end if;
    
  
    
   update emp set comm=v_comm where empno=v_empno;
   
   end loop;
   
   commit;
   
   --关闭游标
   close my_cursor;
   
   --异常
   exception
     when others then
       rollback;
        dbms_output.put_line('error');
end p_update_comm;
/

